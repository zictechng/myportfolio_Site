<div id="header-sticky-mobile" class="tp-md-menu header-transparent d-lg-none pt-40 pb-40">
      <div class="container-fluid">
         <div class="row align-items-center">
            <div class="col-6">
               <div class="tp-logo">
                  <a href="#"><img src="assets/img/logo/logo.png" alt=""></a>
               </div>
            </div>
            <div class="col-6">
               <div class="bar text-end">
                  <button class="tp-menu-bar" type="submit"><i class="fal fa-bars"></i></button>
               </div>
            </div>
         </div>
      </div>
   </div>