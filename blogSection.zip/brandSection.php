<div class="tp-brand-area pt-135 grey-bg">
      <div class="container">
         <div class="row">
            <div class="col-12">
               <div class="tp-brand-section text-center pb-60">
                  <h4 class="tp-brand-title">I Build Solutions for...</h4>
               </div>
            </div>
         </div>
         <div class="tp-brand-slider-section">
            <div class="swiper-container brand-slider-active">
               <div class="swiper-wrapper d-flex align-items-center">
                  <div class="swiper-slide">
                     <div class="tp-brand-icon text-center">
                        <img src="assets/img/brand/brand-1.png" alt="">
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-brand-icon text-center">
                        <img src="assets/img/brand/brand-2.png" alt="">
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-brand-icon text-center">
                        <img src="assets/img/brand/brand-3.png" alt="">
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-brand-icon text-center">
                        <img src="assets/img/brand/brand-4.png" alt="">
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-brand-icon text-center">
                        <img src="assets/img/brand/brand-5.png" alt="">
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-brand-icon text-center">
                        <img src="assets/img/brand/brand-6.png" alt="">
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-brand-icon text-center">
                        <img src="assets/img/brand/brand-6.png" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>