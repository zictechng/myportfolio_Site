<div class="tp-offcanvas-area">
      <div class="tpoffcanvas">
         
         <div class="tpoffcanvas__close-btn">
            <a class="close-btn" href="javascript:void(0)"><i class="fal fa-times-hexagon"></i></a>
         </div>
         <div class="tpoffcanvas__content d-none d-sm-block">
            <p>I deploy quality applications <br> on demand</p>
         </div>
         <div class="mobile-menu">

         </div>
         <div class="tpoffcanvas__contact">
            <span>Contact me</span>
            <ul>
               
               <li><i class="fas fa-phone"></i> <a href="tel:447884619833">+44 788 4619 833</a></li>
               <li><i class="fas fa-envelope"></i> <a href="mailto:abelken99@gmail.com">abelken99@gmail.com</a></li>
            </ul>
         </div>
         
      </div>
   </div>