<header class="d-none d-lg-block">
      <div id="header-sticky" class="tp-header-area-two tp-header-bg header-transparent header-transparent-two">
         <div class="container-fluid">
            <div class="row align-items-center">
               <div class="col-xxl-3 col-xl-3 col-lg-3">
                  <div class="tp-logo text-start">
                     <a href="index.html"><img src="assets/img/logo/logo-blue.png" alt=""></a>
                  </div>
               </div>
               <div class="col-xxl-5 col-xl-6 col-lg-6">
                  <div class="tp-main-menu tp-menu-black tp-bs-menu tp-bp-menu text-center">
                     <nav id="mobile-menu">
                        <ul>
                           <li class="has-dropdown"><a href="index">Home</a> 
                             
                           </li>
                           <li><a href="about">About</a></li>
                           <li><a href="project">Project</a></li>
                           <li><a href="contact">Contact</a></li>
                        </ul>
                     </nav>
                  </div>
               </div>
               <div class="col-xxl-4 col-xl-3 col-lg-3">
                  <div class="tp-header-left d-flex align-items-center justify-content-end ">
                     
                     <div class="tp-header-yellow-button">
                        <a class="tp-btn-white" href="tel:447884619833"> <i class="fas fa-phone"></i> Call Me</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>