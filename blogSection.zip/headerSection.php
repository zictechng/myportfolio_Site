<header class="d-none d-lg-block">
      <div id="header-sticky" class="tp-header-area header-transparent pl-165 pr-165 pt-35">
         <div class="container-fluid">
            <div class="row align-items-center">
               <div class="col-xl-3 col-lg-3">
                  <div class="tp-logo">
                     <a href="index"><img src="assets/img/logo/logo-blue.png" alt=""></a>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7">
                  <div class="tp-main-menu">
                     <nav id="mobile-menu">
                        <ul>
                           <li class="has-dropdown"><a href="index">Home</a> 
                           </li>
                           <li><a href="about">About</a></li>
                           <li><a href="project">Project</a></li>
                           <li><a href="contact">Contact</a></li>
                        </ul>
                     </nav>
                  </div>
               </div>
               <div class="col-xl-2 col-lg-2">
                  <div class="tp-menu-bar text-end">
                     <button><i class="fal fa-bars"></i></button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>