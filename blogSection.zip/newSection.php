<div class="tp-news-letter-area pb-140 wow tpfadeUp" data-wow-duration=".7s" data-wow-delay=".4s">
      <div class="container">
         <div class="tp-news-letter-box p-relative" data-background="assets/img/news/news-shape.png">
            <div class="row">
               <div class="col-xl-6 col-lg-6 col-md-8 col-12  ">
                  <div class="tp-news-wrapper pl-90 z-index-1">
                     <div class="tp-news-letter-section-box">
                        <h5 class="tp-subtitle subtitle-secondary-color">Get update</h5>
                        <h2 class="tp-title tp-white-text">Get latest updates and deals</h2>
                     </div>
                     <div class="tp-news-button p-relative">
                        <form action="#">
                           <input type="text" placeholder="Enter your mail">
                           <button class="tp-submit-button tp-btn-yellow-semilar" type="submit">Subscribe <i
                                 class="far fa-arrow-right"></i></button>
                        </form>
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 text-lg-end col-md-4  ">
                  <div class="tp-news-letter-img">
                     <img src="assets/img/news/news-1.png" alt="">
                  </div>
               </div>
            </div>
            <div class="tp-news-shape-img">
               <img src="assets/img/news/news-shape-2.png" alt="">
            </div>
         </div>
      </div>
   </div>