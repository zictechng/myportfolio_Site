<div class="tp-testimonial-area black-bg pt-130 pb-130 fix">
      <div class="container-fluid">
         <div class="row">
            <div class="col-xl-12">
               <div class="tp-testimonial-section-box text-center pb-25">
                  <h5 class="tp-subtitle">Client Testimonial</h5>
                  <h2 class="tp-title tp-white-text">Customer feedback</h2>
               </div>
            </div>
         </div>
         <div class="tp-testimonial-slider-section d-flex justify-content-center mb-50">
            <div class="swiper-container testimonial-slider-active">
               <div class="swiper-wrapper">
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class="tp-testi-img mr-20"><img src="assets/img/testimonial/testi-1.png" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Darrell Steward</h3>
                                 <h6>Founder of (Rirax)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Collax was very diligent, polite and extremely customer oriented. I think Monika will
                              go
                              far with that attitude and ...he is such a honest, decent and reliable.</p>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class="tp-testi-img mr-20"><img src="assets/img/testimonial/testi-2.jpg" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Floyd Miles</h3>
                                 <h6>CEO of (Orix)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Collax was very diligent, polite and extremely customer oriented. I think Monika will
                              go
                              far with that attitude and ...he is such a honest, decent and reliable.</p>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class=" tp-testi-img mr-20"><img src="assets/img/testimonial/testi-3.png" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Albert Flores</h3>
                                 <h6>Founder of (Rirax)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Collax was very diligent, polite and extremely customer oriented. I think Monika will
                              go
                              far with that attitude and ...he is such a honest, decent and reliable.</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="tp-testimonial-slider-section-2 d-flex justify-content-center">
            <div class="swiper-container testimonial-slider-active-2">
               <div class="swiper-wrapper">
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class="tp-testi-img mr-20"><img src="assets/img/testimonial/testi-4.jpg" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Dianne Russell</h3>
                                 <h6>CEO of (Orix)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Absolutely amazing. we can't believe how incredible this turned out. Yetta Thomas is a
                              true professional. he is such a honest, decent and reliable. He always provide good
                              service</p>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class="tp-testi-img mr-20"><img src="assets/img/testimonial/testi-5.jpg" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Jerome Bell</h3>
                                 <h6>CEO of (Orix)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Collax is a very talented designer and his most valuable role is to teach design in a
                              professional way. He trained design courses under my company Chartered Professional</p>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class=" tp-testi-img mr-20"><img src="assets/img/testimonial/testi-6.jpg" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Floyd Miles</h3>
                                 <h6>CEO of (Orix)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Absolutely amazing. we can't believe how incredible this turned out. Yetta Thomas is a
                              true professional. he is such a honest, decent and reliable. He always provide good
                              service</p>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class=" tp-testi-img mr-20"><img src="assets/img/testimonial/testi-4.jpg" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Robert Fox</h3>
                                 <h6>CEO of (Orix)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Absolutely amazing. we can't believe how incredible this turned out. Yetta Thomas is a
                              true professional. he is such a honest, decent and reliable. He always provide good
                              service</p>
                        </div>
                     </div>
                  </div>
                  <div class="swiper-slide">
                     <div class="tp-testimonial-item">
                        <div class="tp-testi-meta d-flex justify-content-between mb-40">
                           <div class="tp-testi-icon-box d-flex align-items-center">
                              <div class=" tp-testi-img mr-20"><img src="assets/img/testimonial/testi-5.jpg" alt="">
                              </div>
                              <div class="tp-testi-client-position">
                                 <h3>Floyd Miles</h3>
                                 <h6>CEO of (Orix)</h6>
                              </div>
                           </div>
                           <div class="tp-testi-ratting">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                           </div>
                        </div>
                        <div class="tp-testi-p-text">
                           <p>Absolutely amazing. we can't believe how incredible this turned out. Yetta Thomas is a
                              true professional. he is such a honest, decent and reliable. He always provide good
                              service</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>